**IMPORTANT** - Carefully read all the terms and conditions of this agreement before installing this software package. Installing this package indicates your acceptance of theses terms and conditions. If you do not accept these terms and conditions, contact LINDO Systems Inc., 1415 N. Dayton St., Chicago, IL, 60642, for instructions on return of this package for a refund.





**LINDO Systems License Agreement**

Subject to the following terms and conditions, LINDO Systems Inc. (LINDO) hereby grants to you a non-exclusive license to use the LINDO Systems Inc. software program (the "SOFTWARE") contained on the enclosed media and related documentation.



**Software License**

**License**

Except as set forth below, LINDO grants to you the right to use the SOFTWARE on any single computer. You may also install a copy for your exclusive use on either a home computer or portable computer. You may store or install a copy of the SOFTWARE on a storage device, such as a network server, used only to install or run the SOFTWARE over an internal network; however, you must acquire and dedicate a license for each individual who will use the SOFTWARE. If the license is installed on a network server or other system that physically allows shared access to the SOFTWARE, you agree to provide technical or procedural methods to prevent use of the SOFTWARE by individuals not specifically licensed to use the SOFTWARE pursuant to this Agreement.



**Transfer**

The SOFTWARE may be transferred to a single recipient on a permanent basis provided you retain no copies of the SOFTWARE nor documentation (including backup or archival copies) and the recipient agrees to the terms and conditions of this license agreement. At the time of the transfer of the SOFTWARE, you must transfer all media and documentation including any updated media and documentation.



**Copyright**

The SOFTWARE and its related documentation are copyrighted and protected by US copyright laws and international treaty provisions. You may not use, copy, modify, or transfer the SOFTWARE or related documentation except as expressly provided in the license agreement or with written permission of LINDO Systems Inc.



**Restrictions Against Distribution**

You may not distribute, lease, sublease, rent, or sublicense the SOFTWARE or related documentation without written permission of LINDO Systems, Inc.



**Limited Warranty**

LINDO Systems Inc. warrants that the enclosed media and the copy of the related documentation to be free of defects in materials and workmanship for a period of one year from receipt of your payment. Due to the inherent complexity of computer programs and mathematical models, the SOFTWARE and your mathematical models may not be completely free of errors. You are advised to verify your answers before basing decisions on them. **NEITHER LINDO SYSTEMS INC. NOR ANYONE ASSOCIATED WITH THE CREATION, PRODUCTION, OR DISTRIBUTION OF THE SOFTWARE MAKES ANY OTHER EXPRESSED WARRANTIES REGARDING THE MEDIA OR DOCUMENTATION AND MAKES NO WARRANTIES AT ALL, EITHER EXPRESSED OR IMPLIED, REGARDING THE SOFTWARE, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR OTHERWISE.**



**Remedy**

LINDO's entire liability and your exclusive remedy for breach of this Limited Warrant shall be, at LINDO's Option, either return of the price paid or replacement of defective media or documentation. In no event shall LINDO Systems Inc. be liable for any damages including but not limited to loss of profit, data, or direct, indirect, special or consequential damages, even if LINDO has been specifically advised of the possibility of such damages.



**General**

This agreement gives you specific rights, and you may also have other rights that vary from state to state. This License Agreement is governed by, and shall be construed in accordance with, the laws of the State of Illinois.

